#ifndef _LANZA_INCLUDE
#define _LANZA_INCLUDE

#include "Sprite.h"
#include "TileMap.h"

class Lanza
{
public:
    void init(const glm::ivec2& pos, bool facingRight, ShaderProgram& shaderProgram);
    void update(int deltaTime, bool keepPressed);
    void render();

    bool isActive() const;

private:
    enum Estado { EXTENDIENDO, PUNTA, INACTIVA } estado;

    Texture spritesheet;
    Sprite* sprite;
    glm::ivec2 position;
    glm::ivec2 size = glm::ivec2(32, 8);
    bool facingRight;
    int timer;
    int extensionDuration = 200;
    bool active = true;
};

#endif // _LANZA_INCLUDE
