#include "Lanza.h"
#include "Game.h"

void Lanza::init(const glm::ivec2& pos, bool facingRight, ShaderProgram& shaderProgram)
{
    spritesheet.loadFromFile("images/lanzas.png", TEXTURE_PIXEL_FORMAT_RGBA);
    sprite = Sprite::createSprite(size, glm::vec2(0.5f, 0.25f), &spritesheet, &shaderProgram);
    sprite->setNumberAnimations(3); // 0: anim derecha, 1: anim izquierda, 2: punta fija

    // Animaci�n derecha (0,0) -> (0.5,0) -> (0,0.25)
    sprite->setAnimationSpeed(0, 12);
    sprite->addKeyframe(0, glm::vec2(0.f, 0.f));
    sprite->addKeyframe(0, glm::vec2(0.5f, 0.f));
    sprite->addKeyframe(0, glm::vec2(0.f, 0.25f));

    // Animaci�n izquierda (0,0.5) -> (0.5,0.5) -> (0,0.75)
    sprite->setAnimationSpeed(1, 12);
    sprite->addKeyframe(1, glm::vec2(0.f, 0.5f));
    sprite->addKeyframe(1, glm::vec2(0.5f, 0.5f));
    sprite->addKeyframe(1, glm::vec2(0.f, 0.75f));

    // Punta fija
    sprite->setAnimationSpeed(2, 1);
    sprite->addKeyframe(2, facingRight ? glm::vec2(0.f, 0.f) : glm::vec2(0.f, 0.5f));

    this->facingRight = facingRight;
    if (facingRight)
    {
        sprite->changeAnimation(0);
        position = pos + glm::ivec2(28, 14);
    }
    else
    {
        sprite->changeAnimation(1);
        position = pos - glm::ivec2(24, -14);
    }

    sprite->setPosition(glm::vec2(position));
    estado = EXTENDIENDO;
    timer = 0;
    active = true;
}

void Lanza::update(int deltaTime, bool keepPressed)
{
    if (!active) return;

    sprite->update(deltaTime);
    timer += deltaTime;

    if (estado == EXTENDIENDO && timer >= extensionDuration)
    {
        if (keepPressed)
        {
            sprite->changeAnimation(2); // pasar a punta
            estado = PUNTA;
        }
        else
        {
            active = false;
            estado = INACTIVA;
        }
    }
    else if (estado == PUNTA && !keepPressed)
    {
        active = false;
        estado = INACTIVA;
    }
}

void Lanza::render()
{
    if (active)
        sprite->render();
}

bool Lanza::isActive() const
{
    return active;
}
